


import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import Classes.*;

public class Start
{
	public static void main(String[] args)
	{
	    Frame1 f1=new Frame1();
	
		f1.setVisible(true);
		
		
		
	}
}